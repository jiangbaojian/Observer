﻿/*
 * 挂观察者模式（Observer）
 * 2017年7月17日15:47:09
 * 利用委托
 * 事件：
 * 北京到上海
 * 火车到站通知乘务组，车站，乘客
 * 
 * */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 观察者模式
{
    class train
    {
        public string ID = "G65";//随便定义一个
        public int distinces;//距离
        public delegate void RunningEvnetHandler(Object sender,RunningEventArgs e);
        public event RunningEvnetHandler Running;

        public class RunningEventArgs:EventArgs
        {
            public readonly int distances;
            public RunningEventArgs(int distances)
            {
                this.distances = distances;
            }
                
        }
        
        public virtual void OnRunning(RunningEventArgs e)
        {
            if (Running!=null)
            {
                Running(this, e);
            }
        }
        public void RunTrain()
        {
            for (int i = 0; i < 100; i++)
            {
                distinces = i;
                if (distinces>95)
                {
                    RunningEventArgs e = new RunningEventArgs(distinces);
                    OnRunning(e);
                }
            }
        }

    }
    //车站
    class station
    {
        public void ReceiveTrain(Object sender,train.RunningEventArgs e)
        {
            train t = (train)sender;
            Console.WriteLine("{0}就要到站，请车站准备接车,火车还有{1}Km",t.ID,e.distances);
        }
    }
    class passage
    {
        public void Package(Object sender, train.RunningEventArgs e)
        {
            train t = (train)sender;
            Console.WriteLine("{0}就要到站，请收拾行李准备下车,火车还有{1}Km", t.ID, e.distances);
        }
    }
    class waiter
    {
        public void CheckTickets(Object sender, train.RunningEventArgs e)
        {
            train t = (train)sender;
            Console.WriteLine("{0}就要到站，准备检票,火车还有{1}Km", t.ID, e.distances);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            train t = new train();
            station station = new station();
            t.Running+=station.ReceiveTrain;
            t.Running += (new passage()).Package;
            t.Running += new train.RunningEvnetHandler((new waiter()).CheckTickets);//注册
            t.RunTrain();
            Console.ReadKey();
        }
    }
    
}
